package com.example.logintask.model


class UserModel(val _id: Int = -1, val name: String, val email: String, val city: String, val address: String, val password:  String)